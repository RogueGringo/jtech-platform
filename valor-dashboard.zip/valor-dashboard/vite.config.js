import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  // Replace 'valor-dashboard' with your actual repo name
  base: '/valor-dashboard/',
})
